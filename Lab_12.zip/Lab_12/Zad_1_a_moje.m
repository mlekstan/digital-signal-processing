clear all; close all;

[x,cmap] = imread('im1.png');

figure;
imshow(x,cmap), title('im1.png');

DCT2 = dct2(x); 
[rows_num,columns_num] = size(DCT2); 

figure;
imshow(DCT2,cmap), title('im1.png - DCT2');

IDCT2 = idct2(DCT2);

figure;
imshow(IDCT2,cmap), title('im1.png - IDCT2');

DCT2_trans = DCT2.';
DCT2_vector = DCT2_trans(:);


fraction = 0.0125;
threshold = fraction * max(DCT2_vector(2:end));
DCT2_zeros = zeros(rows_num,columns_num);

p = 0; k = 0; s = 0;
for i=2:length(DCT2_vector)
    if (abs(DCT2_vector(i)) > threshold && p == 0)
        DCT2_vector(i) = 0;
        p = p + 1;
        k = k + 1;
        s = s + 1;
    elseif (abs(DCT2_vector(i)) > threshold && p ~= 0)
        p = 0;
        s = s + 1; 
    end
    
    rem = mod(i,128);
    if (rem == 0)
        DCT2_zeros(i/columns_num,:) = DCT2_vector((i-columns_num)+1:i);
    end
end

figure;
imread(DCT2_zeros); title('im1.png - DCT2 po zerowaniu');

IDCT2_zeros = idct2(DCT2_zeros);

figure;
imshow(IDCT2_zeros,cmap); title('im1.png - IDCT2 po zerowaniu DCT2');










