clear all; close all;

% wczytaj obraz
image = imread('im2.png');
image = double(image);
image = rescale(image);

% wyświelt
figure;
imshow(image);

% dct2
image_dct2 = dct2(image);
figure;
imshow(image_dct2);

% own dct 2D
IMG = zeros(128, 128);
for i = 1 : 128
    row = image(i, :);
    ROW = dct(row);
    IMG(i, :) = ROW;
end

figure;
imshow(IMG);
title("Pół mojego dct");

for i = 1 : 128
    col = IMG(:, i);
    COL = dct(col);
    IMG(:, i) = COL;
end

figure;
imshow(IMG);
title("Moje dct");